// Cloudflare Worker: يخزن مفتاح Gemini كـ Secret باسم GEMINI_API_KEY.
// لا تضع المفتاح في هذا الملف أو في GitHub.
const MODEL = "gemini-2.5-flash";

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (url.pathname !== "/reply" || request.method !== "POST")
      return json({ error: "Not found" }, 404, cors);
    if (!env.GEMINI_API_KEY) return json({ error: "Server API secret is not configured" }, 500, cors);

    // حد أقصى لحجم الطلب لتقليل إساءة الاستخدام والتكاليف.
    const raw = await request.text();
    if (raw.length > 12000) return json({ error: "Prompt too long" }, 413, cors);
    let body;
    try { body = JSON.parse(raw); } catch { return json({ error: "Invalid JSON" }, 400, cors); }
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (!prompt) return json({ error: "Prompt is required" }, 400, cors);

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`;
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.8, maxOutputTokens: 500 }
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return json({ error: "AI provider error", detail: data.error?.message || "Request failed" }, 502, cors);
    const text = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim() || "";
    return json({ text }, 200, cors);
  }
};

function json(data, status, cors) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...cors }
  });
}
