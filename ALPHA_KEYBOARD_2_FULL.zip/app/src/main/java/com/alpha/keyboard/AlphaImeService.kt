package com.alpha.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class AlphaImeService : InputMethodService() {
    private lateinit var db: SnippetDb
    private lateinit var panel: LinearLayout
    override fun onCreate() { super.onCreate(); db = SnippetDb(this) }

    override fun onCreateInputView(): View {
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,8,8,8); setBackgroundColor(Color.rgb(238,241,247)) }
        panel.addView(TextView(this).apply { text = "ALPHA KEYBOARD 2.0"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.BLACK) })
        panel.addView(Button(this).apply { text = "تحديث الأكواد"; setOnClickListener { refresh() } })
        val scroll = ScrollView(this)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(items)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(Button(this).apply { text = "إخفاء لوحة المفاتيح"; setOnClickListener { requestHideSelf(0) } })
        refresh()
        return panel
    }
    private fun refresh() {
        if (!::panel.isInitialized) return
        val scroll = panel.getChildAt(2) as ScrollView
        val items = scroll.getChildAt(0) as LinearLayout
        items.removeAllViews()
        val snippets = db.all()
        if (snippets.isEmpty()) items.addView(TextView(this).apply { text = "احفظ الأكواد من تطبيق ALPHA أولاً"; setTextColor(Color.DKGRAY) })
        snippets.forEach { s ->
            items.addView(Button(this).apply {
                text = "${s.title} (${s.body.length} حرف)"
                isAllCaps = false
                setOnClickListener {
                    val ic = currentInputConnection
                    if (ic != null) ic.commitText(s.body, 1)
                    else Toast.makeText(this@AlphaImeService, "افتح حقل كتابة أولاً", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}
