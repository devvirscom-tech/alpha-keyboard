package com.alpha.keyboard

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    // ضع رابط خادمك المنشور هنا من داخل إعدادات التطبيق، وليس مفتاح Gemini.
    fun generate(serverUrl: String, prompt: String): String {
        require(serverUrl.startsWith("https://")) { "يجب استخدام رابط HTTPS آمن" }
        val conn = (URL(serverUrl.trimEnd('/') + "/reply").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        try {
            val payload = JSONObject().put("prompt", prompt).toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw Exception("الخادم أعاد الخطأ $code: $response")
            return JSONObject(response).optString("text", "لم يصل رد من الذكاء الاصطناعي")
        } finally { conn.disconnect() }
    }
}
