package com.alpha.keyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var db: SnippetDb
    private lateinit var list: LinearLayout
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("alpha_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = SnippetDb(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,16) }
        root.addView(TextView(this).apply { text = "ALPHA KEYBOARD 2.0\nحافظة أكواد + مساعد AI"; textSize = 22f })
        val server = EditText(this).apply {
            hint = "رابط خادم AI الآمن (HTTPS)"
            setText(prefs.getString("server_url", ""))
            singleLine = true
        }
        root.addView(TextView(this).apply { text = "إعداد خادم الذكاء الاصطناعي"; textSize = 16f })
        root.addView(server)
        root.addView(Button(this).apply {
            text = "حفظ رابط الخادم"
            setOnClickListener {
                prefs.edit().putString("server_url", server.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "تم حفظ الرابط", Toast.LENGTH_SHORT).show()
            }
        })
        val prompt = EditText(this).apply {
            hint = "اكتب رسالة أو الصق سياق المحادثة لاقتراح رد"
            minLines = 3; gravity = android.view.Gravity.TOP
        }
        root.addView(prompt, LinearLayout.LayoutParams(-1, 0, 1f))
        val result = TextView(this).apply { text = "سيظهر اقتراح الرد هنا"; textSize = 16f }
        root.addView(Button(this).apply {
            text = "ALPHA AI — رد ذكي"
            setOnClickListener { runAi(server.text.toString(), prompt.text.toString(), "اكتب رداً مناسباً ومحترماً ومختصراً على الرسالة التالية: ", result) }
        })
        root.addView(Button(this).apply {
            text = "ALPHA MODE — أسلوب فخم وواثق"
            setOnClickListener { runAi(server.text.toString(), prompt.text.toString(), "أعد صياغة النص التالي بأسلوب عربي واثق وفخم وحازم دون تهديد أو إهانة: ", result) }
        })
        root.addView(result)
        root.addView(Button(this).apply {
            text = "نسخ الرد"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("ALPHA", result.text))
                Toast.makeText(this@MainActivity, "تم نسخ الرد", Toast.LENGTH_SHORT).show()
            }
        })
        val title = EditText(this).apply { hint = "اسم الكود" }
        val body = EditText(this).apply { hint = "الصق كود Python الطويل هنا"; minLines = 6; gravity = android.view.Gravity.TOP; setSingleLine(false) }
        root.addView(TextView(this).apply { text = "حافظة الأكواد"; textSize = 18f })
        root.addView(title)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "حفظ الكود"
            setOnClickListener {
                if (body.text.isNullOrBlank()) Toast.makeText(this@MainActivity, "اكتب الكود أولاً", Toast.LENGTH_SHORT).show()
                else { db.add(title.text.toString().ifBlank { "كود بدون اسم" }, body.text.toString()); title.text.clear(); body.text.clear(); refresh(); Toast.makeText(this@MainActivity, "تم الحفظ محلياً", Toast.LENGTH_SHORT).show() }
            }
        })
        root.addView(Button(this).apply { text = "تفعيل لوحة ALPHA"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } })
        root.addView(Button(this).apply { text = "اختيار لوحة ALPHA"; setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } })
        root.addView(TextView(this).apply { text = "الأكواد المحفوظة:"; textSize = 18f })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun runAi(url: String, text: String, prefix: String, output: TextView) {
        if (url.isBlank() || text.isBlank()) { Toast.makeText(this, "أدخل رابط الخادم والنص أولاً", Toast.LENGTH_LONG).show(); return }
        output.text = "جارٍ تجهيز الرد..."
        io.execute {
            try {
                val answer = ApiClient.generate(url, prefix + text)
                runOnUiThread { output.text = answer }
            } catch (e: Exception) {
                runOnUiThread { output.text = "تعذر الاتصال: ${e.message}" }
            }
        }
    }

    private fun refresh() {
        list.removeAllViews()
        db.all().forEach { s ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply { text = "${s.title} • ${s.body.length} حرف"; textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply { text = "نسخ"; setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText(s.title, s.body))
                Toast.makeText(this@MainActivity, "تم النسخ", Toast.LENGTH_SHORT).show()
            } })
            row.addView(Button(this).apply { text = "حذف"; setOnClickListener { db.delete(s.id); refresh() } })
            list.addView(row)
        }
    }
    override fun onDestroy() { io.shutdown(); super.onDestroy() }
}
