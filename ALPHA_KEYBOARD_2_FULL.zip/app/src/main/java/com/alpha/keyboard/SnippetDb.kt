package com.alpha.keyboard

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

data class Snippet(val id: Long, val title: String, val body: String)

class SnippetDb(context: Context) : SQLiteOpenHelper(context, "alpha_snippets.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE snippets (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(title: String, body: String) {
        writableDatabase.insert("snippets", null, ContentValues().apply {
            put("title", title); put("body", body); put("created", System.currentTimeMillis())
        })
    }
    fun all(): List<Snippet> {
        val out = mutableListOf<Snippet>()
        readableDatabase.rawQuery("SELECT id,title,body FROM snippets ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Snippet(c.getLong(0), c.getString(1), c.getString(2)))
        }
        return out
    }
    fun delete(id: Long) { writableDatabase.delete("snippets", "id=?", arrayOf(id.toString())) }
}
